package School2_김태하;

import java.util.Random;
import java.util.Vector;

public class SubjectDAO {
    Vector<Subject> subjects = new Vector<>();
    Random random = new Random();
    Util util = new Util();
    String fileName = "subject.txt";
    public void addSubject(StudentDAO studentDAO){
        while (true){
            int num = util.getNum("학번");
            Student student = studentDAO.getStudentNum(num);
            if (student == null) {
                System.out.println("존재하지 않는 학번입니다.");
                continue;
            }
            String name = util.getValue("과목명");
            Subject subject = getSubject(name, student.getNum());
            if (subject != null) {
                System.out.println("이미 존재하는 과목명입니다.");
                continue;
            }
            subject = new Subject();
            subject.setNum(num);
            subject.setName(name);
            subject.setScore(random.nextInt(101));
            subjects.add(subject);
            System.out.println("학번 : " + subject.getNum() + " ID : " + student.getId() + " 이름 : " + student.getName() + " 과목명 : " + subject.getName() + " 점수 : " + subject.getScore() + "이 추가되었습니다.");
            break;
        }
    }
    public void removeSubject(StudentDAO studentDAO){
        while (true){
            int num = util.getNum("학번");
            Student student = studentDAO.getStudentNum(num);
            if (student == null) {
                System.out.println("존재하지 않는 학번입니다.");
                continue;
            }
            String name = util.getValue("과목명");
            Subject subject = getSubject(name);
            if (subject == null) {
                System.out.println("존재하지 않는 과목명입니다.");
                continue;
            }
            subjects.remove(subject);
            System.out.println("학번 : " + subject.getNum() + " ID : " + student.getId() + " 이름 : " + student.getName() + " 과목명 : " + subject.getName() + " 점수 : " + subject.getScore() + "이 삭제되었습니다.");
            break;
        }
    }
    public Subject getSubject(String name, int num){
        for (int i = 0; i < subjects.size(); i++) {
            Subject subject = subjects.get(i);
            if (subject.getName().equals(name) && subject.getNum() == num) {
                return subject;
            }
        }
        return null;
    }
    public Subject getSubject(String name){
        for (int i = 0; i < subjects.size(); i++) {
            Subject subject = subjects.get(i);
            if (subject.getName().equals(name)) {
                return subject;
            }
        }
        return null;
    }
    public void printSubject(StudentDAO studentDAO, SubjectDAO subjectDAO){
        while (true){
            String name = util.getValue("과목명");
            Subject subject = getSubject(name);
            if (subject == null) {
                System.out.println("존재하지 않는 과목명입니다.");
                continue;
            }
            int score[][] = getScore(subjectDAO, name);
            for (int i = 0; i < score.length; i++){
                for (Student s : studentDAO.students) {
                    if (score[i][0] == s.getNum()) {
                        System.out.println("학번" + s.getNum() + " ID : " + s.getId() + " 이름 : " + s.getName() + " 점수 : " + score[i][1]);
                        break;
                    }
                }
            }
            break;
        }
    }
    private int[][] getScore(SubjectDAO subjectDAO, String name) {
        int[][] score = new int[subjectDAO.subjects.size()][2];
        int idx = 0;
        for (int i = 0; i < score.length; i++){
            if (subjectDAO.subjects.get(i).getName().equals(name)) {
                score[idx][0] = subjectDAO.subjects.get(i).getNum();
                score[idx][1] = subjectDAO.subjects.get(i).getScore();
                idx++;
            }
        }
        for (int i = 0; i < score.length - 1; i++){
            for (int j = 0; j < score.length; j++){
                if (score[i][1] > score[j][1]){
                    int temp = score[j][1];
                    score[j][1] = score[i][1];
                    score[i][1] = temp;

                    int temp2 = score[j][0];
                    score[j][0] = score[i][0];
                    score[i][0] = temp2;
                }
            }
        }

        return score;
    }
}
