package School2_김태하;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Util {
    Scanner scanner = new Scanner(System.in);
    String CUR_DIR = System.getProperty("user.dir");
    public int getValue(String message, int min, int max){
        while (true) {
            System.out.printf("%s(%d ~ %d) : ", message, min, max);
            try {
                int value = scanner.nextInt();
                scanner.nextLine();
                if (value < min || value > max) {
                    System.out.printf("%d ~ %d 사이의 값을 입력해주세요.\n", min, max);
                    continue;
                }
                return value;
            }catch (Exception e){
                System.out.println("숫자를 입력해주세요.");
                scanner.nextLine();
            }
        }
    }
    public int getNum(String message){
        while (true) {
            System.out.printf("%s : ", message);
            try {
                int value = scanner.nextInt();
                scanner.nextLine();
                return value;
            }catch (Exception e){
                System.out.println("숫자를 입력해주세요.");
                scanner.nextLine();
            }
        }

    }
    public String getValue(String message){
        System.out.printf("%s : ", message);
        return scanner.nextLine();
    }
    public void saveFile(StudentDAO studentDAO, SubjectDAO subjectDAO){
        String studentData = StudentData(studentDAO);
        String subjectData = SubjectData(subjectDAO);

        saveStudent(studentData);
        saveSubject(subjectData);
    }
    private void saveStudent(String data){
        try (FileWriter fw = new FileWriter(CUR_DIR + "/src/School_김태하/student.txt")) {
            fw.write(data);
        } catch (Exception e) {
            System.out.println("파일 저장 실패");
        }
    }
    private void saveSubject(String data){
        try (FileWriter fw = new FileWriter(CUR_DIR + "/src/School_김태하/subject.txt")) {
            fw.write(data);
        } catch (Exception e) {
            System.out.println("파일 저장 실패");
        }
    }
    private String StudentData(StudentDAO studentDAO){
        String data = "";
        for (int i = 0; i < studentDAO.students.size(); i++) {
            Student student = studentDAO.students.get(i);
            data += String.format("%d,%s,%s\n", student.getNum(), student.getId(), student.getName());
        }
        return data;
    }
    private String SubjectData(SubjectDAO subjectDAO){
        String data = "";
        for (int i = 0; i < subjectDAO.subjects.size(); i++) {
            Subject subject = subjectDAO.subjects.get(i);
            data += String.format("%d,%s,%d\n", subject.getNum(), subject.getName(), subject.getScore());
        }
        return data;
    }
    public void loadFile(StudentDAO studentDAO, SubjectDAO subjectDAO){
        String studentData = loadStudent(studentDAO);
        String subjectData = loadSubject();

        loadStudentData(studentData, studentDAO);
        loadSubjectData(subjectData, subjectDAO);
    }
    private String loadStudent(StudentDAO studentDAO){
        String data = "";
        try (FileReader fr = new FileReader(CUR_DIR + "/src/School_김태하/student.txt");
             BufferedReader br = new BufferedReader(fr)) {
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }
                data += line + "\n";
                studentDAO.cnt++;
            }
        } catch (Exception e) {
            System.out.println("파일 불러오기 실패");
        }
        return data;
    }
    private String loadSubject(){
        String data = "";
        try (FileReader fr = new FileReader(CUR_DIR + "/src/School_김태하/subject.txt");
             BufferedReader br = new BufferedReader(fr)) {
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }
                data += line + "\n";
            }
        } catch (Exception e) {
            System.out.println("파일 불러오기 실패");
        }
        return data;
    }
    private void loadStudentData(String data, StudentDAO studentDAO){
        String[] temp = data.split("\n");
        for (int i = 0; i < temp.length; i++) {
            String[] temp2 = temp[i].split(",");
            Student student = new Student();
            student.setNum(Integer.parseInt(temp2[0]));
            student.setId(temp2[1]);
            student.setName(temp2[2]);
            studentDAO.students.add(student);
        }
    }
    private void loadSubjectData(String data, SubjectDAO subjectDAO){
        String[] temp = data.split("\n");
        for (int i = 0; i < temp.length; i++) {
            String[] temp2 = temp[i].split(",");
            Subject subject = new Subject();
            subject.setNum(Integer.parseInt(temp2[0]));
            subject.setName(temp2[1]);
            subject.setScore(Integer.parseInt(temp2[2]));
            subjectDAO.subjects.add(subject);
        }
    }
}
