package School2_김태하;

public class Subject {
    private String name;
    private int score;
    private int num;
    public String getName() {
        return name;
    }
    public int getScore() {
        return score;
    }
    public int getNum() {
        return num;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setScore(int score) {
        this.score = score;
    }
    public void setNum(int num) {
        this.num = num;
    }

}
