package School2_김태하;

public class Main {
    public static void main(String[] args) {
        Controller controller = new Controller();
        controller.run();
    }
}
