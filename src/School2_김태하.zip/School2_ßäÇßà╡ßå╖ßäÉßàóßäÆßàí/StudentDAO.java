package School2_김태하;

import java.util.Arrays;
import java.util.Vector;

public class StudentDAO {
    Vector<Student> students = new Vector<Student>();
    Util util = new Util();
    int cnt = 1001;
    String fileName = "student.txt";
    public void addStudent() {
        while (true){
            String id = util.getValue("ID");
            Student student = getStudent(id);
            if (student != null) {
                System.out.println("이미 존재하는 ID입니다.");
                continue;
            }
            student = new Student();
            student.setId(id);
            student.setName(util.getValue("이름"));
            student.setNum(cnt++);
            students.add(student);
            System.out.println("학번 : " + student.getNum() + " ID : " + student.getId() + " 이름 : " + student.getName() + "학생이 추가되었습니다.");
            break;
        }
    }
    public Student getStudent(String id) {
        for (int i = 0; i < students.size(); i++) {
            Student student = students.get(i);
            if (student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }
    public Student getStudentNum(int num) {
       for (Student s : students) {
           System.out.println(s.getNum());
           if (s.getNum() == num) {
               return s;
           }
       }
       return null;
    }
    public void removeStudent() {
        while (true){
            String id = util.getValue("ID");
            Student student = getStudent(id);
            if (student == null) {
                System.out.println("존재하지 않는 ID입니다.");
                continue;
            }
            students.remove(student);
            System.out.println("학번 : " + student.getNum() + " ID : " + student.getId() + " 이름 : " + student.getName() + "학생이 삭제되었습니다.");
            cnt--;
            break;
        }
    }
    public void printAllStudent(SubjectDAO subjectDAO) {
        int score[][] = getScore(subjectDAO, this);
        for (int i = 0; i < score.length; i++) {
            for (Student s : students) {
                if (s.getNum() == score[i][0]) {
                    System.out.println("학번 : " + s.getNum() + " ID : " + s.getId() + " 이름 : " + s.getName() + " 점수 : " + score[i][1]);
                }
            }
        }
    }
    private int[][] getScore(SubjectDAO subjectDAO, StudentDAO studentDAO) {
        int scores[][] = new int[subjectDAO.subjects.size()][2];
        for (int i = 0; i < scores.length; i++) {
            scores[i][0] = subjectDAO.subjects.get(i).getNum();
            scores[i][1] = subjectDAO.subjects.get(i).getScore();
        }
        for (int i = 0; i < scores.length; i++) {
            for (int j = i + 1; j < scores.length; j++) {
                if (scores[i][0] == scores[j][0]) {
                    scores[i][1] += scores[j][1];
                    scores[j][0] = 0;
                }
            }
        }
        Arrays.sort(scores, (a, b) -> Integer.compare(b[1], a[1]));
        return scores;
    }
}
