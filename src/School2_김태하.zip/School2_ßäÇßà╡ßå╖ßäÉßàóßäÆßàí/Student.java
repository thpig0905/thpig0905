package School2_김태하;

public class Student {
    private String name;
    private String id;
    private int num;
    public String getName() {
        return name;
    }
    public String getId() {
        return id;
    }
    public int getNum() {
        return num;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setNum(int num) {
        this.num = num;
    }
}
