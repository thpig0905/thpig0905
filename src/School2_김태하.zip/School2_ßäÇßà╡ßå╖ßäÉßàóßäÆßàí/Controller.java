package School2_김태하;

public class Controller {
    Util util = new Util();
    StudentDAO studentDAO = new StudentDAO();
    SubjectDAO subjectDAO = new SubjectDAO();
    void printMenu(){
        System.out.println("[1] 학생추가");
        System.out.println("[2] 학생삭제");
        System.out.println("[3] 과목추가");
        System.out.println("[4] 과목삭제");
        System.out.println("[5] 학생 전체 출력");
        System.out.println("[6] 한 과목 학생 출력");
        System.out.println("[7] 파일 저장");
        System.out.println("[8] 파일 불러오기");
        System.out.println("[0] 종료");
    }
    void run(){
        util.loadFile(studentDAO, subjectDAO);
        while (true){
            printMenu();
            int sel = util.getValue("메뉴를 선택하세요", 0, 8);
            if (sel == 1) {
                System.out.println("학생추가");
                studentDAO.addStudent();
            } else if (sel ==2) {
                System.out.println("학생삭제");
                studentDAO.removeStudent();
            } else if (sel == 3) {
                System.out.println("과목추가");
                subjectDAO.addSubject(studentDAO);
            } else if (sel == 4) {
                System.out.println("과목삭제");
                subjectDAO.removeSubject(studentDAO);
            } else if (sel == 5) {
                System.out.println("학생 전체 출력");
                studentDAO.printAllStudent(subjectDAO);
            } else if (sel == 6) {
                System.out.println("한 과목 학생 출력");
                subjectDAO.printSubject(studentDAO, subjectDAO);
            } else if (sel == 7) {
                System.out.println("파일 저장");
                util.saveFile(studentDAO, subjectDAO);
            } else if (sel == 8) {
                System.out.println("파일 불러오기");
                util.loadFile(studentDAO, subjectDAO);
            } else if (sel == 0) {
                System.out.println("종료");
                break;
            }

            System.out.println("----------------------------------");
        }
    }
}
